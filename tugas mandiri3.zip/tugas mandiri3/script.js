function main () {
    let nomor = document.getElementById("nomor").value

    confirm("Apakah anda yakin dengan inputan Anda?")

    nomor == 2 ? alert("Angka yang anda masukkan benar adalah 2") : alert(`Angka yang anda masukkan salah adalah ${nomor}`)

}